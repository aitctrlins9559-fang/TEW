import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  StockPosition,
  MarketType,
  MarketIndex,
  NewsItem,
  ChartTarget,
  ApiHealthStatus,
  AIAnalysisResult,
  TransactionRecord,
} from './types';
import { Header } from './components/Header';
import { KpiCards } from './components/KpiCards';
import { MarketIndices } from './components/MarketIndices';
import { LunarFortuneCard } from './components/LunarFortuneCard';
import { PerformanceBanners } from './components/PerformanceBanners';
import { NewsMarquee } from './components/NewsMarquee';
import { StockTable } from './components/StockTable';
import { IntegratedAssetHub } from './components/IntegratedAssetHub';
import { AssetTrendChart } from './components/Charts/AssetTrendChart';
import { AllocationPieChart } from './components/Charts/AllocationPieChart';
import { SlidersHorizontal, Activity, TrendingUp, Sparkles } from 'lucide-react';
import { MobileBottomNav } from './components/MobileBottomNav';
import { SingleStockChart } from './components/Charts/SingleStockChart';
import { FullStockChartModal } from './components/Charts/FullStockChartModal';
import { StockModal } from './components/Modals/StockModal';
import { TransactionHistoryModal } from './components/Modals/TransactionHistoryModal';
import { TodayPLModal } from './components/Modals/TodayPLModal';
import { SyncModal } from './components/Modals/SyncModal';
import { ActionModal } from './components/Modals/ActionModal';
import { AICopilotModal } from './components/Modals/AICopilotModal';
import { VersionHistoryModal } from './components/Modals/VersionHistoryModal';
import { DeleteConfirmModal } from './components/Modals/DeleteConfirmModal';
import { AdminPasswordModal } from './components/Modals/AdminPasswordModal';
import { DividendCalendarModal } from './components/Modals/DividendCalendarModal';
import { AssetAnalysisModal } from './components/Modals/AssetAnalysisModal';
import { DividendCalendar } from './components/DividendCalendar';
import { ApiDebugPanel } from './components/ApiDebugPanel';
import { getTaiwanDateString, getTaiwanTimeString } from './utils/format';
import {
  apiFetchFx,
  apiFetchQuotes,
  apiFetchIndices,
  apiFetchNews,
  apiRunAIAnalysis,
} from './utils/apiClient';
import {
  playSuccessSound,
  playDeleteSound,
  playCoinSound,
  playShieldBreakSound,
  playClickSound,
} from './utils/audio';
import { PieChart, BarChart2, Calendar, Plus } from 'lucide-react';

const INITIAL_PORTFOLIO: StockPosition[] = [
  {
    id: 'stk_1',
    symbol: '2330',
    name: '台積電',
    market: 'tse',
    shares: 1000,
    cost: 850,
    buyDate: '2024-05-10',
    buyRate: 1,
    price: 980,
    prevClose: 975,
    dayHigh: 985,
    dayLow: 970,
    transactions: [
      { id: 'tx_1', buyDate: '2024-05-10', shares: 1000, cost: 850, buyRate: 1 },
    ],
  },
  {
    id: 'stk_2',
    symbol: 'NVDA',
    name: 'NVIDIA 輝達',
    market: 'us',
    shares: 50,
    cost: 110,
    buyDate: '2024-06-15',
    buyRate: 32.2,
    price: 128,
    prevClose: 125,
    dayHigh: 130,
    dayLow: 124,
    transactions: [
      { id: 'tx_2', buyDate: '2024-06-15', shares: 50, cost: 110, buyRate: 32.2 },
    ],
  },
  {
    id: 'stk_3',
    symbol: '0050',
    name: '元大台灣50',
    market: 'tse',
    shares: 2000,
    cost: 155,
    buyDate: '2024-01-20',
    buyRate: 1,
    price: 172,
    prevClose: 170,
    dayHigh: 173,
    dayLow: 169,
    transactions: [
      { id: 'tx_3', buyDate: '2024-01-20', shares: 2000, cost: 155, buyRate: 1 },
    ],
  },
];

export default function App() {
  // State variables
  const [portfolio, setPortfolio] = useState<StockPosition[]>([]);
  const portfolioRef = useRef<StockPosition[]>(portfolio);
  useEffect(() => {
    portfolioRef.current = portfolio;
  }, [portfolio]);

  const [usdTwdRate, setUsdTwdRate] = useState<number>(31.5);
  const [indices, setIndices] = useState<MarketIndex[]>([]);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [lastNewsTime, setLastNewsTime] = useState<string>('');

  const [isAdmin, setIsAdmin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [isRedUp, setIsRedUp] = useState(true);
  const [isPrivacy, setIsPrivacy] = useState(false);

  // Layout & View Mode States
  const [showIndices, setShowIndices] = useState(true);
  const [showBanners, setShowBanners] = useState(true);
  const [showAssetHub, setShowAssetHub] = useState(true);

  // Mobile quick view mode selector ('all' | 'overview' | 'portfolio' | 'charts' | 'ai')
  const [activeMobileTab, setActiveMobileTab] = useState<'all' | 'overview' | 'portfolio' | 'charts' | 'ai'>('all');

  const [isAutoRefreshOn, setIsAutoRefreshOn] = useState(true);
  const [activeRefreshInterval, setActiveRefreshInterval] = useState(60);
  const [countdownTimer, setCountdownTimer] = useState(60);
  const [isFetchingPrices, setIsFetchingPrices] = useState(false);

  const [cloudSyncUrl, setCloudSyncUrl] = useState('');
  const [lastSyncTime, setLastSyncTime] = useState('');
  const [lastCloudWriteTime, setLastCloudWriteTime] = useState('');
  const [quoteSuccessCount, setQuoteSuccessCount] = useState(0);

  const [toastMessage, setToastMessage] = useState<{ text: string; isSuccess: boolean } | null>(null);

  // Market hours status
  const [twMarketOpen, setTwMarketOpen] = useState(false);
  const [usMarketOpen, setUsMarketOpen] = useState(false);

  // Selected chart target
  const [selectedChartTarget, setSelectedChartTarget] = useState<ChartTarget>({
    symbol: '2330',
    market: 'tse',
    name: '台積電',
  });

  // Modal control states
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [editStock, setEditStock] = useState<StockPosition | null>(null);

  const [isTxHistoryModalOpen, setIsTxHistoryModalOpen] = useState(false);
  const [txHistoryStock, setTxHistoryStock] = useState<StockPosition | null>(null);

  const [isTodayPLModalOpen, setIsTodayPLModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isFullChartModalOpen, setIsFullChartModalOpen] = useState(false);
  const [isAdminPasswordModalOpen, setIsAdminPasswordModalOpen] = useState(false);
  const [isDividendModalOpen, setIsDividendModalOpen] = useState(false);
  const [isAssetAnalysisModalOpen, setIsAssetAnalysisModalOpen] = useState(false);

  const [deleteConfirmState, setDeleteConfirmState] = useState<{
    isOpen: boolean;
    type: 'stock' | 'tx';
    stockId: string;
    txId?: string;
    itemName?: string;
    message?: string;
  }>({
    isOpen: false,
    type: 'stock',
    stockId: '',
  });

  const [actionModal, setActionModal] = useState<{
    isOpen: boolean;
    type: 'mvp' | 'lvp' | null;
    name: string;
    profitStr: string;
    roi: number;
  }>({ isOpen: false, type: null, name: '', profitStr: '', roi: 0 });

  // AI Copilot state
  const [isAICopilotOpen, setIsAICopilotOpen] = useState(false);
  const [isVersionModalOpen, setIsVersionModalOpen] = useState(false);
  const [isAIAnalyzing, setIsAIAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<AIAnalysisResult | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);

  // Api health status
  const [apiHealth, setApiHealth] = useState<ApiHealthStatus>({
    cloud: { name: 'Cloud API', status: 'PENDING', ms: 0, error: null },
    yahoo: { name: 'Yahoo Quote', status: 'PENDING', ms: 0, error: null },
    twse: { name: 'TWSE API', status: 'PENDING', ms: 0, error: null },
    tpex: { name: 'TPEX API', status: 'PENDING', ms: 0, error: null },
    search: { name: 'Stock Search', status: 'OK', ms: 120, error: null },
    fx: { name: 'FX API', status: 'PENDING', ms: 0, error: null },
  });

  const toastTimerRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = useCallback((msg: string, isSuccess = true) => {
    setToastMessage({ text: msg, isSuccess });
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  }, []);

  // Save portfolio to local & sync to cloud
  const savePortfolioLocal = useCallback(
    async (newPortfolio: StockPosition[], syncUrl = cloudSyncUrl) => {
      localStorage.setItem('stock_radar_data', JSON.stringify(newPortfolio));

      if (syncUrl && syncUrl.includes('script.google.com') && isAdmin && adminPassword) {
        try {
          const res = await fetch(syncUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
            body: JSON.stringify({ password: adminPassword, data: newPortfolio }),
          });
          const result = await res.json();
          if (result.status === 'success') {
            setLastCloudWriteTime(`${getTaiwanDateString()} ${getTaiwanTimeString()}`);
          }
        } catch {
          // ignore background sync error
        }
      }
    },
    [cloudSyncUrl, isAdmin, adminPassword]
  );

  // Normalize raw portfolio data
  const normalizePortfolio = useCallback((data: unknown[]): StockPosition[] => {
    if (!Array.isArray(data)) return [];
    return data
      .filter((item) => item && typeof item === 'object')
      .map((item: Record<string, unknown>) => {
        const txs: TransactionRecord[] =
          Array.isArray(item.transactions) && item.transactions.length > 0
            ? (item.transactions as TransactionRecord[])
            : [
                {
                  id: `tx_init_${Date.now()}`,
                  buyDate: typeof item.buyDate === 'string' ? item.buyDate : '',
                  shares: Number(item.shares) || 0,
                  cost: Number(item.cost) || 0,
                  buyRate: Number(item.buyRate) || 1,
                },
              ];

        let totalShares = 0;
        let totalCostVal = 0;
        let totalBuyRateVal = 0;

        txs.forEach((t) => {
          const s = Number(t.shares) || 0;
          const c = Number(t.cost) || 0;
          const r = Number(t.buyRate) || 1;
          totalShares += s;
          totalCostVal += s * c;
          totalBuyRateVal += s * r;
        });

        const avgCost = totalShares > 0 ? totalCostVal / totalShares : Number(item.cost || 0);
        const avgBuyRate = totalShares > 0 ? totalBuyRateVal / totalShares : Number(item.buyRate || 1);
        const lastBuyDate =
          txs.length > 0 ? txs[txs.length - 1].buyDate : (item.buyDate as string) || '';

        return {
          id: String(item.id || `stk_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`),
          symbol: String(item.symbol || '').trim().toUpperCase(),
          name: String(item.name || item.symbol || '').trim(),
          market: (['tse', 'otc', 'us'].includes(item.market as string) ? item.market : 'tse') as MarketType,
          transactions: txs,
          shares: totalShares,
          cost: Number(avgCost.toFixed(4)),
          buyDate: lastBuyDate,
          buyRate: Number(avgBuyRate.toFixed(2)),
          price: typeof item.price === 'number' && item.price > 0 ? item.price : null,
          prevClose: typeof item.prevClose === 'number' && item.prevClose > 0 ? item.prevClose : null,
          dayHigh: typeof item.dayHigh === 'number' ? item.dayHigh : null,
          dayLow: typeof item.dayLow === 'number' ? item.dayLow : null,
          fetchError: Boolean(item.fetchError),
        };
      })
      .filter(
        (item) =>
          item.symbol &&
          item.name &&
          Number.isFinite(item.shares) &&
          item.shares > 0 &&
          Number.isFinite(item.cost) &&
          item.cost >= 0
      );
  }, []);

  // Fetch quotes from server or CORS fallback
  const fetchRealtimePrices = useCallback(async (isManual = false) => {
    setIsFetchingPrices(true);
    const tStart = performance.now();

    try {
      // 1. Fetch USD rate
      const newFx = await apiFetchFx();
      setUsdTwdRate(newFx);

      // 2. Fetch quotes for all portfolio stocks
      const currentPortfolio = portfolioRef.current;
      if (currentPortfolio.length > 0) {
        const symbols = currentPortfolio.map((p) =>
          p.market === 'tse' ? `${p.symbol}.TW` : p.market === 'otc' ? `${p.symbol}.TWO` : p.symbol
        );

        const results = await apiFetchQuotes(symbols);

        let success = 0;
        let twseSuccess = false;
        let tpexSuccess = false;

        const updated = currentPortfolio.map((item) => {
          const symKey =
            item.market === 'tse'
              ? `${item.symbol}.TW`
              : item.market === 'otc'
              ? `${item.symbol}.TWO`
              : item.symbol;

          const itemBare = item.symbol.replace(/\.(TW|TWO)$/i, '').trim().toUpperCase();

          const q = results.find((r) => {
            if (!r || !r.symbol) return false;
            const rUpper = r.symbol.toUpperCase();
            const rBare = rUpper.replace(/\.(TW|TWO)$/i, '').trim();
            return (
              rUpper === symKey.toUpperCase() ||
              rUpper === item.symbol.toUpperCase() ||
              rBare === itemBare
            );
          });

          if (q && typeof q.regularMarketPrice === 'number') {
            success++;
            if (item.market === 'tse') twseSuccess = true;
            if (item.market === 'otc') tpexSuccess = true;

            const oldPrice = item.price;
            const newPrice = q.regularMarketPrice;
            let priceChanged: 'up' | 'down' | null = null;

            if (oldPrice !== null && oldPrice !== undefined) {
              if (newPrice > oldPrice) priceChanged = 'up';
              else if (newPrice < oldPrice) priceChanged = 'down';
            }

            return {
              ...item,
              price: newPrice,
              prevClose: q.regularMarketPreviousClose || item.prevClose || newPrice,
              dayHigh: q.regularMarketDayHigh || item.dayHigh || newPrice,
              dayLow: q.regularMarketDayLow || item.dayLow || newPrice,
              fetchError: false,
              priceChanged,
            };
          }
          return { ...item, fetchError: true };
        });

        setQuoteSuccessCount(success);
        setPortfolio(updated);
        savePortfolioLocal(updated);

        const elapsedMs = Math.round(performance.now() - tStart);
        setApiHealth((prev) => ({
          ...prev,
          cloud: { name: 'Cloud API', status: cloudSyncUrl ? 'OK' : 'DISABLED', ms: 50, error: null },
          yahoo: { name: 'Yahoo Quote', status: success > 0 ? 'OK' : 'ERROR', ms: elapsedMs, error: success > 0 ? null : '無行情數據' },
          twse: { name: 'TWSE API', status: twseSuccess ? 'OK' : 'DISABLED', ms: Math.round(elapsedMs * 0.8), error: null },
          tpex: { name: 'TPEX API', status: tpexSuccess ? 'OK' : 'DISABLED', ms: Math.round(elapsedMs * 0.9), error: null },
          search: { name: 'Stock Search', status: 'OK', ms: 120, error: null },
          fx: { name: 'FX API', status: 'OK', ms: 80, error: null },
        }));
      }

      // 3. Fetch indices
      const idxResults = await apiFetchIndices();
      if (Array.isArray(idxResults) && idxResults.length > 0) {
        setIndices(idxResults);
      }

      setLastSyncTime(`${getTaiwanDateString()} ${getTaiwanTimeString()}`);

      if (isManual) {
        playSuccessSound();
        if (currentPortfolio.length > 0 && quoteSuccessCount > 0) {
          showToast(`盤價與匯率同步完成！`);
        } else {
          showToast(`盤價與匯率同步完成！`);
        }
      }
    } catch {
      if (isManual) showToast('行情連線逾時，請檢查網路狀態', false);
    } finally {
      setIsFetchingPrices(false);
      setCountdownTimer(60);
    }
  }, [showToast, savePortfolioLocal, cloudSyncUrl]);

  // Fetch news
  const fetchNews = useCallback(async () => {
    try {
      const items = await apiFetchNews();
      if (Array.isArray(items) && items.length > 0) {
        setNews(items);
        setLastNewsTime(getTaiwanTimeString());
      }
    } catch {
      // ignore
    }
  }, []);

  // AI Copilot analysis request
  const handleRunAIAnalysis = useCallback(async () => {
    setIsAIAnalyzing(true);
    setAiError(null);

    let totalValTWD = 0;
    let totalCostTWD = 0;

    portfolio.forEach((p) => {
      const fx = p.market === 'us' ? usdTwdRate : 1;
      const c = p.shares * p.cost * (p.market === 'us' ? p.buyRate : 1);
      const v = p.price ? p.shares * p.price * fx : c;
      totalCostTWD += c;
      totalValTWD += v;
    });

    const profit = totalValTWD - totalCostTWD;
    const roi = totalCostTWD > 0 ? (profit / totalCostTWD) * 100 : 0;

    try {
      const analysis = await apiRunAIAnalysis({
        portfolio,
        totalValue: Math.round(totalValTWD),
        totalProfit: Math.round(profit),
        totalROI: Number(roi.toFixed(2)),
        indices,
      });
      setAiAnalysisResult(analysis);
    } catch (err) {
      setAiError((err as Error).message);
    } finally {
      setIsAIAnalyzing(false);
    }
  }, [portfolio, usdTwdRate, indices]);

  // Initial load
  useEffect(() => {
    const savedSyncUrl = localStorage.getItem('stock_radar_sync_url') || '';
    setCloudSyncUrl(savedSyncUrl);

    const savedData = localStorage.getItem('stock_radar_data');
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        setPortfolio(normalizePortfolio(parsed));
      } catch {
        setPortfolio(normalizePortfolio(INITIAL_PORTFOLIO));
      }
    } else {
      setPortfolio(normalizePortfolio(INITIAL_PORTFOLIO));
    }

    fetchRealtimePrices();
    fetchNews();
  }, [normalizePortfolio, fetchRealtimePrices, fetchNews]);

  // Market hours check & Smart timer
  useEffect(() => {
    const checkMarketStatus = () => {
      const now = new Date();
      const twDay = now.getDay();
      const twHour = now.getHours();
      const twMin = now.getMinutes();
      const isTwWeekday = twDay >= 1 && twDay <= 5;
      const isTwOpenTime =
        (twHour === 9 && twMin >= 0) || (twHour > 9 && twHour < 13) || (twHour === 13 && twMin <= 30);
      setTwMarketOpen(isTwWeekday && isTwOpenTime);

      const nyDate = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
      const nyDay = nyDate.getDay();
      const nyHour = nyDate.getHours();
      const nyMin = nyDate.getMinutes();
      const isNyWeekday = nyDay >= 1 && nyDay <= 5;
      const isNyOpenTime = (nyHour === 9 && nyMin >= 30) || (nyHour >= 10 && nyHour < 16);
      setUsMarketOpen(isNyWeekday && isNyOpenTime);

      const isAnyOpen = (isTwWeekday && isTwOpenTime) || (isNyWeekday && isNyOpenTime);
      const targetInterval = isAnyOpen ? 15 : 60;
      setActiveRefreshInterval(targetInterval);
    };

    checkMarketStatus();
    const interval = setInterval(checkMarketStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  // Countdown timer loop
  useEffect(() => {
    if (!isAutoRefreshOn || isFetchingPrices) return;

    const timer = setInterval(() => {
      setCountdownTimer((prev) => {
        if (prev <= 1) {
          fetchRealtimePrices();
          return activeRefreshInterval;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isAutoRefreshOn, isFetchingPrices, activeRefreshInterval, fetchRealtimePrices]);

  // Admin toggle
  const handleToggleAdmin = () => {
    if (isAdmin) {
      setIsAdmin(false);
      setAdminPassword('');
      showToast('已鎖定管理權限');
    } else {
      setIsAdminPasswordModalOpen(true);
    }
  };

  // Stock Save
  const handleSaveStock = (stockData: {
    editId: string;
    symbol: string;
    name: string;
    market: MarketType;
    shares: number;
    cost: number;
    buyDate: string;
    buyRate: number;
  }) => {
    const newTx: TransactionRecord = {
      id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      buyDate: stockData.buyDate,
      shares: stockData.shares,
      cost: stockData.cost,
      buyRate: stockData.buyRate,
    };

    let updated: StockPosition[];

    if (stockData.editId) {
      updated = portfolio.map((item) =>
        item.id === stockData.editId
          ? {
              ...item,
              symbol: stockData.symbol,
              name: stockData.name,
              market: stockData.market,
              transactions: [newTx],
              shares: stockData.shares,
              cost: stockData.cost,
              buyDate: stockData.buyDate,
              buyRate: stockData.buyRate,
            }
          : item
      );
      showToast('持股資料已更新！');
    } else {
      const existingIdx = portfolio.findIndex(
        (p) => p.symbol === stockData.symbol && p.market === stockData.market
      );

      if (existingIdx !== -1) {
        updated = [...portfolio];
        updated[existingIdx].transactions.push(newTx);
        showToast(`已為 ${stockData.symbol} 新增買入紀錄並加權平均成本！`);
      } else {
        const newItem: StockPosition = {
          id: `stk_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          symbol: stockData.symbol,
          name: stockData.name,
          market: stockData.market,
          transactions: [newTx],
          shares: stockData.shares,
          cost: stockData.cost,
          buyDate: stockData.buyDate,
          buyRate: stockData.buyRate,
          price: null,
          prevClose: null,
          dayHigh: null,
          dayLow: null,
        };
        updated = [...portfolio, newItem];
        showToast('持股部位新增成功！');
      }
    }

    const normalized = normalizePortfolio(updated);
    setPortfolio(normalized);
    savePortfolioLocal(normalized);
    setIsStockModalOpen(false);
    playSuccessSound();
    fetchRealtimePrices();
  };

  // Stock Delete
  const handleDeleteStock = (id: string) => {
    const stock = portfolio.find((p) => p.id === id);
    if (!stock) return;
    setDeleteConfirmState({
      isOpen: true,
      type: 'stock',
      stockId: id,
      itemName: `${stock.name} (${stock.symbol})`,
      message: '確定要移除此持股部位嗎？該操作將會從監控列表中移除，無法復原。',
    });
  };

  // Add sub-transaction
  const handleAddTransaction = (
    stockId: string,
    buyDate: string,
    shares: number,
    cost: number
  ) => {
    const updated = portfolio.map((item) => {
      if (item.id === stockId) {
        const newTx: TransactionRecord = {
          id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          buyDate,
          shares,
          cost,
          buyRate: item.market === 'us' ? usdTwdRate : 1,
        };
        return {
          ...item,
          transactions: [...item.transactions, newTx],
        };
      }
      return item;
    });

    const normalized = normalizePortfolio(updated);
    setPortfolio(normalized);
    savePortfolioLocal(normalized);
    showToast('已成功加入買入歷程！');
    playSuccessSound();

    // Update open modal stock
    const updatedStock = normalized.find((p) => p.id === stockId);
    if (updatedStock) setTxHistoryStock(updatedStock);
  };

  // Delete sub-transaction
  const handleDeleteTransaction = (stockId: string, txId: string) => {
    const item = portfolio.find((p) => p.id === stockId);
    if (!item) return;

    if (item.transactions.length <= 1) {
      showToast('至少需保留一筆買入記錄', false);
      return;
    }

    const tx = item.transactions.find((t) => t.id === txId);
    setDeleteConfirmState({
      isOpen: true,
      type: 'tx',
      stockId,
      txId,
      itemName: tx ? `${item.name} - ${tx.buyDate} ($${tx.cost})` : undefined,
      message: '確定要移除此筆扣款交易紀錄嗎？',
    });
  };

  // Execute actual deletion after user confirms in modal
  const handleExecuteDelete = () => {
    const { type, stockId, txId } = deleteConfirmState;
    playDeleteSound();

    if (type === 'stock') {
      const updated = portfolio.filter((p) => p.id !== stockId);
      setPortfolio(updated);
      savePortfolioLocal(updated);
      showToast('已移除該部位！');
    } else if (type === 'tx' && txId) {
      const updated = portfolio.map((p) => {
        if (p.id === stockId) {
          return {
            ...p,
            transactions: p.transactions.filter((t) => t.id !== txId),
          };
        }
        return p;
      });

      const normalized = normalizePortfolio(updated);
      setPortfolio(normalized);
      savePortfolioLocal(normalized);
      showToast('已刪除該筆扣款紀錄');

      const updatedStock = normalized.find((p) => p.id === stockId);
      if (updatedStock) setTxHistoryStock(updatedStock);
    }

    setDeleteConfirmState((prev) => ({ ...prev, isOpen: false }));
  };

  // Fetch cloud data manually
  const handleFetchCloudData = async (url: string): Promise<boolean> => {
    if (!url) {
      showToast('請先輸入雲端同步網址', false);
      return false;
    }
    showToast('正在從雲端讀取持股數據...');
    try {
      let data: unknown = null;
      try {
        const res = await fetch(url, { method: 'GET' });
        if (res.ok) {
          const json = await res.json();
          data = json.data || json;
        }
      } catch {
        // ignore
      }

      if (!data || !Array.isArray(data) || data.length === 0) {
        const resPost = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify({ action: 'read', password: adminPassword }),
        });
        if (resPost.ok) {
          const jsonPost = await resPost.json();
          data = jsonPost.data || jsonPost;
        }
      }

      if (Array.isArray(data) && data.length > 0) {
        const normalized = normalizePortfolio(data);
        setPortfolio(normalized);
        localStorage.setItem('stock_radar_data', JSON.stringify(normalized));
        showToast(`✅ 成功從雲端讀取 ${normalized.length} 筆持股數據！`);
        playSuccessSound();
        fetchRealtimePrices(true);
        return true;
      } else {
        showToast('雲端未返回有效的持股資料', false);
        return false;
      }
    } catch {
      showToast('連線至雲端網址失敗，請檢查權限與網址', false);
      return false;
    }
  };

  // Push local data to cloud
  const handlePushCloudData = async (url: string): Promise<boolean> => {
    if (!url) {
      showToast('請先輸入雲端同步網址', false);
      return false;
    }
    showToast('正在備份持股至雲端...');
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ password: adminPassword, data: portfolio }),
      });
      const json = await res.json();
      if (json.status === 'success' || json.success) {
        setLastCloudWriteTime(`${getTaiwanDateString()} ${getTaiwanTimeString()}`);
        showToast('✅ 持股部位已成功推送備份至雲端！');
        playSuccessSound();
        return true;
      } else {
        showToast(json.message || '雲端同步失敗', false);
        return false;
      }
    } catch {
      showToast('推送雲端失敗，請確認網路連線與 GAS 部署權限', false);
      return false;
    }
  };

  // Calculations for total portfolio
  let totalValTWD = 0;
  let prevCloseValTWD = 0;
  let totalCostTWD = 0;
  let todayPLTWD = 0;
  let twCount = 0;
  let usCount = 0;
  let hasMissingPrice = false;

  portfolio.forEach((item) => {
    const isUS = item.market === 'us';
    const buyFx = isUS ? item.buyRate || usdTwdRate : 1;
    const marketFx = isUS ? usdTwdRate : 1;

    const costTWD = item.shares * item.cost * buyFx;
    totalCostTWD += costTWD;

    if (typeof item.price === 'number' && item.price > 0) {
      const valTWD = item.shares * item.price * marketFx;
      totalValTWD += valTWD;

      const pClose = typeof item.prevClose === 'number' && item.prevClose > 0 ? item.prevClose : item.price;
      prevCloseValTWD += item.shares * pClose * marketFx;

      if (typeof item.prevClose === 'number' && item.prevClose > 0) {
        todayPLTWD += item.shares * (item.price - item.prevClose) * marketFx;
      }
    } else {
      hasMissingPrice = true;
    }

    if (isUS) usCount++;
    else twCount++;
  });

  const assetTrendHistory = useMemo(() => {
    if (totalValTWD === 0) return { labels: ['09:00', '13:30'], data: [0, 0] };
    const STORAGE_KEY = 'stock_radar_asset_history';
    const saved = localStorage.getItem(STORAGE_KEY);
    let history: Array<{ time: string; val: number }> = [];

    if (saved) {
      try {
        history = JSON.parse(saved);
      } catch {
        history = [];
      }
    }

    const nowTimeStr = getTaiwanTimeString().slice(0, 5);
    const base = prevCloseValTWD > 0 ? prevCloseValTWD : totalValTWD * 0.98;

    if (history.length === 0) {
      const diff = totalValTWD - base;
      const times = ['09:00', '10:00', '11:00', '12:00', '13:00', '13:25', '現價'];
      history = times.map((t, i) => {
        const stepPct = i / (times.length - 1);
        const noise = (Math.sin(i * 1.5) * 0.002 + stepPct) * diff;
        return { time: t, val: Math.round(base + noise) };
      });
    } else {
      const last = history[history.length - 1];
      if (!last || last.time !== nowTimeStr || Math.abs(last.val - totalValTWD) > 10) {
        if (last && last.time === nowTimeStr) {
          history[history.length - 1].val = Math.round(totalValTWD);
        } else {
          history.push({ time: nowTimeStr, val: Math.round(totalValTWD) });
        }
        if (history.length > 25) history = history.slice(-25);
      }
    }

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch {
      // ignore
    }

    return {
      labels: history.map((h) => h.time),
      data: history.map((h) => h.val),
    };
  }, [totalValTWD, prevCloseValTWD]);

  const totalProfitTWD = hasMissingPrice ? null : totalValTWD - totalCostTWD;
  const totalROI =
    hasMissingPrice || totalCostTWD === 0 ? null : (totalProfitTWD! / totalCostTWD) * 100;

  const twiiQ = indices.find((i) => i.symbol === '^TWII');
  const twiiChangePct = twiiQ ? twiiQ.changePct : null;
  const portfolioTodayPct = totalCostTWD > 0 ? (todayPLTWD / totalCostTWD) * 100 : null;

  return (
    <div className="min-h-screen p-3 sm:p-6 lg:p-8 antialiased selection:bg-sky-500 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:bottom-6 bg-slate-800/95 text-white font-medium px-4 sm:px-5 py-3.5 sm:py-4 rounded-2xl shadow-[0_15px_40px_rgba(0,0,0,0.6)] z-[999] flex items-center justify-between sm:justify-start gap-3 border border-slate-600/50 backdrop-blur-xl animate-bounce">
          <span className={toastMessage.isSuccess ? 'text-sky-400 font-bold' : 'text-rose-400 font-bold'}>
            {toastMessage.isSuccess ? '✓' : '✕'}
          </span>
          <span className="text-xs sm:text-sm tracking-wide truncate">{toastMessage.text}</span>
        </div>
      )}

      {/* Main War Room Layout */}
      <div className="max-w-7xl mx-auto space-y-6 pb-20 sm:pb-12">
        {/* Header */}
        <Header
          isAdmin={isAdmin}
          onToggleAdmin={handleToggleAdmin}
          isRedUp={isRedUp}
          onToggleTheme={() => setIsRedUp(!isRedUp)}
          isPrivacy={isPrivacy}
          onTogglePrivacy={() => setIsPrivacy(!isPrivacy)}
          isAutoRefreshOn={isAutoRefreshOn}
          onToggleAutoRefresh={() => setIsAutoRefreshOn(!isAutoRefreshOn)}
          countdownTimer={countdownTimer}
          activeRefreshInterval={activeRefreshInterval}
          onManualRefresh={() => fetchRealtimePrices(true)}
          isFetchingPrices={isFetchingPrices}
          cloudSyncUrl={cloudSyncUrl}
          onOpenSyncModal={() => setIsSyncModalOpen(true)}
          onOpenAddModal={() => {
            setEditStock(null);
            setIsStockModalOpen(true);
          }}
          onOpenAICopilot={() => {
            setIsAICopilotOpen(true);
            if (!aiAnalysisResult) handleRunAIAnalysis();
          }}
          onOpenChangelog={() => setIsVersionModalOpen(true)}
          usdTwdRate={usdTwdRate}
          lastUpdateTime={lastSyncTime}
          twMarketOpen={twMarketOpen}
          usMarketOpen={usMarketOpen}
          quoteSuccessCount={quoteSuccessCount}
          totalPositionsCount={portfolio.length}
        />

        {/* API Connection & Debug Console */}
        <ApiDebugPanel
          apiHealth={apiHealth}
          lastSyncTime={lastSyncTime}
          quoteSuccessCount={quoteSuccessCount}
          totalCount={portfolio.length}
          lastCloudWriteTime={lastCloudWriteTime}
          onRunDiagnostics={() => fetchRealtimePrices(true)}
          isAdmin={isAdmin}
          onToggleAdmin={handleToggleAdmin}
        />

        {/* Quick View Jump Navigation Bar (Sticky Top) */}
        <div className="sticky top-2 z-40 flex flex-wrap items-center justify-between gap-2 bg-slate-900/95 backdrop-blur-xl border border-sky-500/30 rounded-2xl p-2.5 px-4 shadow-[0_10px_30px_rgba(0,0,0,0.5)] text-xs transition-all">
          <div className="flex items-center gap-2 text-slate-200 font-bold shrink-0">
            <SlidersHorizontal className="w-4 h-4 text-sky-400" />
            <span>版面視圖快捷跳轉</span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto py-1">
            <button
              onClick={() => {
                playClickSound();
                if (activeMobileTab !== 'all' && activeMobileTab !== 'overview') {
                  setActiveMobileTab('all');
                }
                setTimeout(() => {
                  document.getElementById('section-indices')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 50);
              }}
              className="px-3 py-1.5 rounded-xl font-bold transition border border-white/10 bg-slate-800/90 hover:bg-sky-500/20 text-slate-200 hover:text-sky-300 hover:border-sky-500/40 flex items-center gap-1.5 btn-interact"
            >
              <Activity className="w-3.5 h-3.5 text-sky-400" />
              <span>大盤戰情</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                if (activeMobileTab !== 'all' && activeMobileTab !== 'overview') {
                  setActiveMobileTab('all');
                }
                setTimeout(() => {
                  document.getElementById('section-performance')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 50);
              }}
              className="px-3 py-1.5 rounded-xl font-bold transition border border-white/10 bg-slate-800/90 hover:bg-amber-500/20 text-slate-200 hover:text-amber-300 hover:border-amber-500/40 flex items-center gap-1.5 btn-interact"
            >
              <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
              <span>領頭與風控</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                if (activeMobileTab !== 'all' && activeMobileTab !== 'charts') {
                  setActiveMobileTab('all');
                }
                setTimeout(() => {
                  document.getElementById('section-assethub')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 50);
              }}
              className="px-3 py-1.5 rounded-xl font-bold transition border border-white/10 bg-slate-800/90 hover:bg-indigo-500/20 text-slate-200 hover:text-indigo-300 hover:border-indigo-500/40 flex items-center gap-1.5 btn-interact"
            >
              <PieChart className="w-3.5 h-3.5 text-indigo-400" />
              <span>全資產樞紐</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                if (activeMobileTab !== 'all' && activeMobileTab !== 'portfolio') {
                  setActiveMobileTab('portfolio');
                }
                setTimeout(() => {
                  document.getElementById('section-portfolio')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 50);
              }}
              className="px-3 py-1.5 rounded-xl font-bold transition border border-white/10 bg-slate-800/90 hover:bg-emerald-500/20 text-slate-200 hover:text-emerald-300 hover:border-emerald-500/40 flex items-center gap-1.5 btn-interact"
            >
              <BarChart2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>持股明細</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                if (activeMobileTab !== 'all') {
                  setActiveMobileTab('all');
                }
                setTimeout(() => {
                  document.getElementById('section-dividends')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 50);
              }}
              className="px-3 py-1.5 rounded-xl font-bold transition border border-white/10 bg-slate-800/90 hover:bg-rose-500/20 text-slate-200 hover:text-rose-300 hover:border-rose-500/40 flex items-center gap-1.5 btn-interact"
            >
              <Calendar className="w-3.5 h-3.5 text-rose-400" />
              <span>預估股息</span>
            </button>
          </div>
        </div>

        {/* Standard Unified Flow Layout with Mobile Tab Filtering */}
        <div className="space-y-6">
          {(activeMobileTab === 'all' || activeMobileTab === 'overview') && (
            <>
              <div id="section-indices" className="scroll-mt-20">
                <MarketIndices
                  indices={indices}
                  twiiChangePct={twiiChangePct}
                  portfolioTodayPct={portfolioTodayPct}
                  isRedUp={isRedUp}
                  onSelectIndex={(symbol, market, name) => {
                    setSelectedChartTarget({ symbol, market, name });
                    setIsFullChartModalOpen(true);
                    const chartCard = document.getElementById('singleStockChartCard');
                    if (chartCard) chartCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  }}
                />
              </div>

              <KpiCards
                totalValue={totalValTWD}
                totalCost={totalCostTWD}
                todayPL={todayPLTWD}
                totalProfit={totalProfitTWD}
                totalROI={totalROI}
                totalCount={portfolio.length}
                twCount={twCount}
                usCount={usCount}
                isPrivacy={isPrivacy}
                isRedUp={isRedUp}
                onOpenTodayPLModal={() => setIsTodayPLModalOpen(true)}
              />

              <div id="section-performance" className="scroll-mt-20">
                <PerformanceBanners
                  portfolio={portfolio}
                  usdTwdRate={usdTwdRate}
                  isPrivacy={isPrivacy}
                  isRedUp={isRedUp}
                  onSelectStock={(symbol, market, name) => {
                    setSelectedChartTarget({ symbol, market, name });
                    setIsFullChartModalOpen(true);
                  }}
                />
              </div>
            </>
          )}

          {(activeMobileTab === 'all' || activeMobileTab === 'charts') && (
            <div id="section-assethub" className="scroll-mt-20">
              <IntegratedAssetHub
                labels={assetTrendHistory.labels}
                data={assetTrendHistory.data}
                currentVal={totalValTWD}
                portfolio={portfolio}
                usdTwdRate={usdTwdRate}
                isPrivacy={isPrivacy}
                isRedUp={isRedUp}
              />
            </div>
          )}

          {(activeMobileTab === 'all' || activeMobileTab === 'portfolio') && (
            <div id="section-portfolio" className="scroll-mt-20">
              <StockTable
                portfolio={portfolio}
                usdTwdRate={usdTwdRate}
                isAdmin={isAdmin}
                isPrivacy={isPrivacy}
                isRedUp={isRedUp}
                onSelectChartTarget={(symbol, market, name) => {
                  setSelectedChartTarget({ symbol, market, name });
                  setIsFullChartModalOpen(true);
                  const chartCard = document.getElementById('singleStockChartCard');
                  if (chartCard) chartCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }}
                onOpenTxHistory={(stockId) => {
                  const stk = portfolio.find((p) => p.id === stockId);
                  if (stk) {
                    setTxHistoryStock(stk);
                    setIsTxHistoryModalOpen(true);
                  }
                }}
                onOpenEditModal={(stockId) => {
                  const stk = portfolio.find((p) => p.id === stockId);
                  if (stk) {
                    setEditStock(stk);
                    setIsStockModalOpen(true);
                  }
                }}
                onDeleteStock={handleDeleteStock}
                onOpenAddModal={() => {
                  setEditStock(null);
                  setIsStockModalOpen(true);
                }}
                onToggleAdmin={handleToggleAdmin}
                onExportData={() => {
                  const jsonStr = JSON.stringify(portfolio, null, 2);
                  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `StockMonitor_Backup_${new Date().toISOString().slice(0, 10)}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  showToast('資料已匯出備份');
                }}
                onImportData={() => {
                  const fileInput = document.createElement('input');
                  fileInput.type = 'file';
                  fileInput.accept = '.json';
                  fileInput.onchange = (e) => {
                    const file = (e.target as HTMLInputElement).files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (evt) => {
                        try {
                          const parsed = JSON.parse(evt.target?.result as string);
                          const normalized = normalizePortfolio(parsed);
                          setPortfolio(normalized);
                          savePortfolioLocal(normalized);
                          showToast('備份資料成功還原！');
                        } catch {
                          showToast('JSON 格式錯誤，請檢查檔案', false);
                        }
                      };
                      reader.readAsText(file);
                    }
                  };
                  fileInput.click();
                }}
              />
            </div>
          )}

          {(activeMobileTab === 'all' || activeMobileTab === 'charts') && (
            <SingleStockChart
              portfolio={portfolio}
              selectedChartTarget={selectedChartTarget}
              onSelectChartTarget={(symbol, market, name) =>
                setSelectedChartTarget({ symbol, market, name })
              }
              isRedUp={isRedUp}
              onOpenFullModal={() => setIsFullChartModalOpen(true)}
            />
          )}

          {activeMobileTab === 'all' && (
            <>
              <NewsMarquee news={news} lastNewsTime={lastNewsTime} />
              <div id="section-dividends" className="scroll-mt-20">
                <DividendCalendar
                  portfolio={portfolio}
                  usdTwdRate={usdTwdRate}
                  isPrivacy={isPrivacy}
                />
              </div>
              <LunarFortuneCard />
            </>
          )}
        </div>
      </div>

      {/* Modals */}
      <StockModal
        isOpen={isStockModalOpen}
        editStock={editStock}
        usdTwdRate={usdTwdRate}
        onClose={() => setIsStockModalOpen(false)}
        onSave={handleSaveStock}
      />

      <TransactionHistoryModal
        isOpen={isTxHistoryModalOpen}
        stock={txHistoryStock}
        isAdmin={isAdmin}
        usdTwdRate={usdTwdRate}
        onClose={() => setIsTxHistoryModalOpen(false)}
        onAddTransaction={handleAddTransaction}
        onDeleteTransaction={handleDeleteTransaction}
      />

      <TodayPLModal
        isOpen={isTodayPLModalOpen}
        portfolio={portfolio}
        usdTwdRate={usdTwdRate}
        isPrivacy={isPrivacy}
        isRedUp={isRedUp}
        onClose={() => setIsTodayPLModalOpen(false)}
        onSelectStock={(symbol, market, name) => {
          setSelectedChartTarget({ symbol, market, name });
          const chartCard = document.getElementById('singleStockChartCard');
          if (chartCard) chartCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }}
      />

      <SyncModal
        isOpen={isSyncModalOpen}
        currentSyncUrl={cloudSyncUrl}
        onClose={() => setIsSyncModalOpen(false)}
        onSaveSyncUrl={(url) => {
          setCloudSyncUrl(url);
          localStorage.setItem('stock_radar_sync_url', url);
          setIsSyncModalOpen(false);
          showToast(url ? '雲端網址已設定' : '已恢復本機模式');
        }}
        onFetchFromCloud={handleFetchCloudData}
        onPushToCloud={handlePushCloudData}
        isAdmin={isAdmin}
      />

      <ActionModal
        isOpen={actionModal.isOpen}
        type={actionModal.type}
        name={actionModal.name}
        profitStr={actionModal.profitStr}
        roi={actionModal.roi}
        isRedUp={isRedUp}
        onClose={() => setActionModal((prev) => ({ ...prev, isOpen: false }))}
      />

      <AICopilotModal
        isOpen={isAICopilotOpen}
        isLoading={isAIAnalyzing}
        analysis={aiAnalysisResult}
        error={aiError}
        portfolio={portfolio}
        totalValue={Math.round(totalValTWD)}
        totalProfit={Math.round(totalProfitTWD || 0)}
        totalROI={Number((totalROI || 0).toFixed(2))}
        indices={indices}
        onClose={() => setIsAICopilotOpen(false)}
        onReanalyze={handleRunAIAnalysis}
      />

      <VersionHistoryModal
        isOpen={isVersionModalOpen}
        onClose={() => setIsVersionModalOpen(false)}
      />

      <FullStockChartModal
        isOpen={isFullChartModalOpen}
        onClose={() => setIsFullChartModalOpen(false)}
        portfolio={portfolio}
        selectedChartTarget={selectedChartTarget}
        onSelectChartTarget={(symbol, market, name) =>
          setSelectedChartTarget({ symbol, market, name })
        }
        isRedUp={isRedUp}
        onOpenAICopilot={() => {
          setIsAICopilotOpen(true);
          if (!aiAnalysisResult) handleRunAIAnalysis();
        }}
      />

      <DeleteConfirmModal
        isOpen={deleteConfirmState.isOpen}
        title={deleteConfirmState.type === 'stock' ? '確認刪除部位' : '確認刪除交易紀錄'}
        message={deleteConfirmState.message}
        itemName={deleteConfirmState.itemName}
        onConfirm={handleExecuteDelete}
        onClose={() => setDeleteConfirmState((prev) => ({ ...prev, isOpen: false }))}
      />

      <AdminPasswordModal
        isOpen={isAdminPasswordModalOpen}
        isAdmin={isAdmin}
        onUnlock={(pwd) => {
          setIsAdmin(true);
          setAdminPassword(pwd);
          showToast('✅ 編輯與備份功能已解鎖');
        }}
        onLock={() => {
          setIsAdmin(false);
          setAdminPassword('');
          showToast('已鎖定管理權限');
        }}
        onClose={() => setIsAdminPasswordModalOpen(false)}
      />

      <DividendCalendarModal
        isOpen={isDividendModalOpen}
        portfolio={portfolio}
        usdTwdRate={usdTwdRate}
        isPrivacy={isPrivacy}
        onClose={() => setIsDividendModalOpen(false)}
      />

      <AssetAnalysisModal
        isOpen={isAssetAnalysisModalOpen}
        portfolio={portfolio}
        usdTwdRate={usdTwdRate}
        isPrivacy={isPrivacy}
        isRedUp={isRedUp}
        labels={assetTrendHistory.labels}
        data={assetTrendHistory.data}
        currentVal={totalValTWD}
        onClose={() => setIsAssetAnalysisModalOpen(false)}
      />

      {/* Floating AI Copilot Shortcut (Desktop & Tablet) */}
      <button
        onClick={() => {
          playClickSound();
          setIsAICopilotOpen(true);
          if (!aiAnalysisResult) handleRunAIAnalysis();
        }}
        className="hidden lg:flex fixed bottom-6 left-6 z-50 bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-3.5 sm:px-4 sm:py-3 rounded-full shadow-[0_0_25px_rgba(168,85,247,0.5)] border border-purple-400/40 hover:scale-105 active:scale-95 transition items-center gap-2 group btn-interact"
        title="開啟 AI 戰情操盤顧問"
      >
        <Sparkles className="w-5 h-5 text-amber-300 animate-spin" style={{ animationDuration: '6s' }} />
        <span className="text-xs font-black tracking-wider">AI 戰情顧問</span>
      </button>

      {/* Native-Like Mobile Bottom Navigation Bar & Quick Action FAB (Mobile & Tablet) */}
      <MobileBottomNav
        activeTab={activeMobileTab}
        onSelectTab={(tab) => setActiveMobileTab(tab)}
        onOpenAddModal={() => {
          setEditStock(null);
          setIsStockModalOpen(true);
        }}
        onOpenAICopilot={() => {
          setIsAICopilotOpen(true);
          if (!aiAnalysisResult) handleRunAIAnalysis();
        }}
        onManualRefresh={() => fetchRealtimePrices(true)}
        isFetchingPrices={isFetchingPrices}
      />
    </div>
  );
}
