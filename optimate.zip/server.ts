import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// CORS headers for local / proxy requests
app.use((_req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

// Utility helper to fetch JSON with timeout
async function fetchWithTimeout(url: string, timeoutMs = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      cache: 'no-store',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      },
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

// 1. USD/TWD Exchange Rate Endpoint
app.get('/api/fx', async (_req, res) => {
  try {
    const data = await fetchWithTimeout('https://open.er-api.com/v6/latest/USD', 5000);
    const twdRate = data?.rates?.TWD || 31.5;
    res.json({ success: true, rate: twdRate });
  } catch {
    // Fallback if er-api is down
    res.json({ success: true, rate: 31.5, fallback: true });
  }
});

// 2. Real-time Quotes Endpoint (TWSE MIS Batch + Yahoo Finance Multi-Host Fallback)
async function fetchYahooChart(sym: string, interval = '1m', range = '1d', timeoutMs = 6000) {
  const hosts = ['query2.finance.yahoo.com', 'query1.finance.yahoo.com'];
  for (const host of hosts) {
    try {
      const url = `https://${host}/v8/finance/chart/${encodeURIComponent(sym)}?interval=${interval}&range=${range}`;
      const data = await fetchWithTimeout(url, timeoutMs);
      const meta = data?.chart?.result?.[0]?.meta;
      if (meta && typeof meta.regularMarketPrice === 'number') {
        return {
          symbol: sym,
          regularMarketPrice: meta.regularMarketPrice,
          regularMarketPreviousClose: meta.chartPreviousClose || meta.previousClose || meta.regularMarketPrice,
          regularMarketDayHigh: meta.regularMarketDayHigh || meta.regularMarketPrice,
          regularMarketDayLow: meta.regularMarketDayLow || meta.regularMarketPrice,
          rawChart: data,
        };
      }
    } catch {
      // try next host
    }
  }
  return null;
}

async function fetchTwseBatch(symbols: string[]) {
  const twItems: { original: string; code: string }[] = [];
  symbols.forEach((sym) => {
    const clean = sym.replace(/\.(TW|TWO)$/i, '').trim().toUpperCase();
    if (/^\d{4,6}[A-Z]?$/i.test(clean)) {
      twItems.push({ original: sym, code: clean });
    }
  });

  if (twItems.length === 0) return [];

  const exChParts: string[] = [];
  twItems.forEach((item) => {
    exChParts.push(`tse_${item.code}.tw`);
    exChParts.push(`otc_${item.code}.tw`);
  });

  try {
    const url = `https://mis.twse.com.tw/stock/api/getStockInfo.jsp?ex_ch=${encodeURIComponent(exChParts.join('|'))}&_=${Date.now()}`;
    const data = await fetchWithTimeout(url, 6000);
    const msgArray = data?.msgArray || [];

    const results: any[] = [];
    twItems.forEach((item) => {
      const match = msgArray.find((m: any) => m.c === item.code && (m.z || m.y || m.a || m.b));
      if (match) {
        let price = parseFloat(match.z);
        if (isNaN(price) || price <= 0) {
          if (match.a && match.a !== '-') price = parseFloat(match.a.split('_')[0]);
          if ((isNaN(price) || price <= 0) && match.b && match.b !== '-') price = parseFloat(match.b.split('_')[0]);
          if (isNaN(price) || price <= 0) price = parseFloat(match.y);
        }
        const prevClose = parseFloat(match.y) || price;
        const dayHigh = parseFloat(match.h) || price;
        const dayLow = parseFloat(match.l) || price;

        if (price > 0) {
          results.push({
            symbol: item.original,
            regularMarketPrice: price,
            regularMarketPreviousClose: prevClose,
            regularMarketDayHigh: dayHigh,
            regularMarketDayLow: dayLow,
          });
          if (item.original !== item.code) {
            results.push({
              symbol: item.code,
              regularMarketPrice: price,
              regularMarketPreviousClose: prevClose,
              regularMarketDayHigh: dayHigh,
              regularMarketDayLow: dayLow,
            });
          }
        }
      }
    });
    return results;
  } catch {
    return [];
  }
}

app.post('/api/quote', async (req, res) => {
  try {
    const { symbols } = req.body as { symbols: string[] };
    if (!Array.isArray(symbols) || symbols.length === 0) {
      return res.json({ success: true, results: [] });
    }

    // 1. Try TWSE MIS Batch for Taiwan stocks
    const twseResults = await fetchTwseBatch(symbols);
    const foundSyms = new Set(twseResults.map((r) => r.symbol.toUpperCase()));

    // 2. Fetch missing / US stocks from Yahoo Finance
    const missingSymbols = symbols.filter((sym) => {
      const upper = sym.toUpperCase();
      const bare = upper.replace(/\.(TW|TWO)$/i, '');
      return !foundSyms.has(upper) && !foundSyms.has(bare);
    });

    const yahooResults = await Promise.all(
      missingSymbols.map((sym) => fetchYahooChart(sym, '1m', '1d', 6000))
    );

    const validYahoo = yahooResults.filter(Boolean);

    const combinedResults = [...twseResults, ...validYahoo];
    res.json({ success: true, results: combinedResults });
  } catch (error) {
    res.status(500).json({ success: false, error: (error as Error).message });
  }
});

// 3. Market Indices Endpoint
app.get('/api/indices', async (_req, res) => {
  const indexSymbols = ['^TWII', '^N225', '^KS11', '^DJI', '^GSPC', '^IXIC'];
  try {
    // Try TWSE MIS for ^TWII (tse_t00.tw)
    let twiiResult: any = null;
    try {
      const url = `https://mis.twse.com.tw/stock/api/getStockInfo.jsp?ex_ch=tse_t00.tw&_=${Date.now()}`;
      const data = await fetchWithTimeout(url, 4000);
      const match = data?.msgArray?.[0];
      if (match) {
        const price = parseFloat(match.z) || parseFloat(match.y);
        const prevClose = parseFloat(match.y) || price;
        if (price > 0) {
          const change = price - prevClose;
          const changePct = prevClose > 0 ? (change / prevClose) * 100 : 0;
          twiiResult = {
            symbol: '^TWII',
            price,
            prevClose,
            change,
            changePct,
          };
        }
      }
    } catch {
      // ignore
    }

    const results = await Promise.all(
      indexSymbols.map(async (sym) => {
        if (sym === '^TWII' && twiiResult) return twiiResult;
        try {
          const chartData = await fetchYahooChart(sym, '1m', '1d', 5000);
          if (chartData && typeof chartData.regularMarketPrice === 'number') {
            const price = chartData.regularMarketPrice;
            const prevClose = chartData.regularMarketPreviousClose;
            const change = price - prevClose;
            const changePct = prevClose > 0 ? (change / prevClose) * 100 : 0;
            return {
              symbol: sym,
              price,
              prevClose,
              change,
              changePct,
            };
          }
        } catch {
          // ignore
        }
        return null;
      })
    );

    res.json({ success: true, results: results.filter(Boolean) });
  } catch (error) {
    res.status(500).json({ success: false, error: (error as Error).message });
  }
});

// 4. Stock Search Endpoint
app.get('/api/search', async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) return res.json({ success: true, results: [] });

  try {
    const url = `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&lang=zh-Hant-TW&region=TW&quotesCount=10&newsCount=0`;
    const data = await fetchWithTimeout(url, 5000);
    const quotes = data?.quotes || [];

    const results = quotes
      .filter((item: { quoteType?: string }) => item.quoteType === 'EQUITY' || item.quoteType === 'ETF')
      .map((item: { symbol: string; shortname?: string; longname?: string }) => {
        let symbol = item.symbol;
        let market: 'tse' | 'otc' | 'us' = 'us';
        if (symbol.endsWith('.TW')) {
          symbol = symbol.slice(0, -3);
          market = 'tse';
        } else if (symbol.endsWith('.TWO')) {
          symbol = symbol.slice(0, -4);
          market = 'otc';
        }
        return {
          symbol,
          name: item.shortname || item.longname || symbol,
          market,
        };
      });

    res.json({ success: true, results });
  } catch (error) {
    res.status(500).json({ success: false, error: (error as Error).message });
  }
});

// 5. Financial News Endpoint
app.get('/api/news', async (_req, res) => {
  try {
    const url = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent('https://tw.stock.yahoo.com/rss')}`;
    const data = await fetchWithTimeout(url, 6000);
    if (data?.status === 'ok' && Array.isArray(data.items)) {
      const items = data.items.slice(0, 15).map((item: { title: string; link: string; pubDate?: string }) => ({
        title: item.title,
        link: item.link,
        pubDate: item.pubDate,
      }));
      return res.json({ success: true, items });
    }
    res.json({ success: true, items: [] });
  } catch (error) {
    res.json({ success: false, error: (error as Error).message, items: [] });
  }
});

// 6. Intraday or Historical Chart Endpoint
app.get('/api/chart', async (req, res) => {
  const symbol = String(req.query.symbol || '').trim();
  const range = String(req.query.range || '1d');
  const interval = String(req.query.interval || '5m');

  if (!symbol) return res.status(400).json({ success: false, error: 'Symbol required' });

  try {
    const chartRes = await fetchYahooChart(symbol, interval, range, 6000);
    if (!chartRes || !chartRes.rawChart) {
      return res.status(404).json({ success: false, error: 'No chart data' });
    }

    const result = chartRes.rawChart?.chart?.result?.[0];
    if (!result) return res.status(404).json({ success: false, error: 'No chart result' });

    res.json({
      success: true,
      meta: result.meta,
      timestamp: result.timestamp || [],
      quotes: result.indicators?.quote?.[0]?.close || [],
      volumes: result.indicators?.quote?.[0]?.volume || [],
      opens: result.indicators?.quote?.[0]?.open || [],
      highs: result.indicators?.quote?.[0]?.high || [],
      lows: result.indicators?.quote?.[0]?.low || [],
    });
  } catch (error) {
    res.status(500).json({ success: false, error: (error as Error).message });
  }
});

// Helper for generating rule-based analysis fallback when Gemini API key is unconfigured or rate limited
function generateRuleBasedAnalysis(
  portfolio: Array<{ name: string; symbol: string; market: string; shares: number; cost: number; price?: number }> = [],
  totalValue: number | string = 0,
  totalProfit: number | string = 0,
  totalROI: number | string = 0
) {
  const valNum = Number(totalValue) || 0;
  const profitNum = Number(totalProfit) || 0;
  const roiNum = typeof totalROI === 'number' ? totalROI : parseFloat(String(totalROI)) || 0;

  const twCount = (portfolio || []).filter((p) => p.market !== 'us').length;
  const usCount = (portfolio || []).filter((p) => p.market === 'us').length;
  const isGain = profitNum >= 0;

  const topPos = [...(portfolio || [])].sort((a, b) => b.shares * (b.price || b.cost) - a.shares * (a.price || a.cost))[0];
  const topName = topPos ? `${topPos.symbol} ${topPos.name}` : '未配置主攻標的';

  return {
    summary: `投資組合目前總估值約 $${Math.round(valNum).toLocaleString()} TWD，累積報酬率為 ${roiNum.toFixed(1)}% (${isGain ? '獲利中' : '處於回檔狀態'})。持股涵蓋 ${twCount} 檔台股與 ${usCount} 檔美股。`,
    riskRating: roiNum < -15 ? '高風險' : roiNum > 20 ? '低風險' : '中等風險',
    allocationComment: `持股佈局呈現台股 ${twCount} 檔、美股 ${usCount} 檔之跨國配置。最大持股部位為 ${topName}，整體資金集中度尚屬健康，建議持續追蹤企業基本面與大盤輪動情況。`,
    topOpportunities: [
      `最大重倉部位 ${topName} 具備良好市場地位與資產覆蓋力。`,
      `雙市場 (台股/美股) 跨區配置有助分散單一市場非系統性風險。`,
    ],
    riskWarnings: [
      roiNum < 0 ? '當前總部位處於未實現虧損，請密切留意大盤支撐位與停損機制。' : '持股累積獲利良好，注意大盤高點震盪與利多出盡之拉回風險。',
      '匯率波動 (如 USD/TWD) 將直接影響美股部位之換算權益市值。',
    ],
    actionAdvice: '建議維持彈性現金儲備，若關鍵權值股回檔至月線/季線支撐位可分批建倉，並定時檢視停損與止盈目標。',
    timestamp: new Date().toLocaleString('zh-TW', { timeZone: 'Asia/Taipei' }),
  };
}

// Helper for generating rule-based chat fallback when Gemini API key is unconfigured or rate limited
function generateRuleBasedChatReply(
  userMessage: string,
  portfolio: Array<{ name: string; symbol: string; market: string; shares: number; cost: number; price?: number }> = [],
  totalValue: number | string = 0,
  totalProfit: number | string = 0,
  totalROI: number | string = 0
) {
  const msg = userMessage.toLowerCase();
  const valNum = Number(totalValue) || 0;
  const profitNum = Number(totalProfit) || 0;
  const roiNum = typeof totalROI === 'number' ? totalROI : parseFloat(String(totalROI)) || 0;

  const topPos = [...(portfolio || [])].sort((a, b) => b.shares * (b.price || b.cost) - a.shares * (a.price || a.cost))[0];
  const topName = topPos ? `${topPos.symbol} ${topPos.name}` : '目前持股';

  if (msg.includes('風險') || msg.includes('止損') || msg.includes('停損')) {
    return `針對您目前的投資組合（總估值約 $${Math.round(valNum).toLocaleString()} TWD，累積報酬率 ${roiNum.toFixed(1)}%）：\n\n1. **最大部位觀測**：您的重倉標的為 **${topName}**，建議關注大盤技術指標（月線與季線支撐）。\n2. **風控策略**：若單一持股未實現虧損超過 15%，可考慮設好分批停損或轉換至防禦性個股。\n3. **資金管理**：保持 15%~20% 現金儲備，以應對美股與台股大盤的高位震盪。`;
  }

  if (msg.includes('股息') || msg.includes('殖利率') || msg.includes('被動收入')) {
    return `關聯您的持股股息規劃：\n\n1. **台股高股息**：台股 ETF (如 0050、0056 等) 提供穩定現金流，建議除息前檢視填息歷史紀錄。\n2. **美股股息**：美股標的除息時會有 30% 預扣稅，建議計算稅後實際殖利率。\n3. **再投資策略**：將發放之股息持續投入具成長潛力之標的，發揮複利效應！`;
  }

  if (msg.includes('台積電') || msg.includes('2330') || msg.includes('tsm')) {
    return `針對 **台積電 (2330/TSM)** 與半導體板塊分析：\n\n- **基本面**：AI 晶片與先進製程產能滿載，長線產業壁壘極強。\n- **短線觀測**：密切追蹤美股 NVDA/TSM ADR 走勢與外資期貨空單變化。\n- **操盤建議**：長線投資人可視拉回至季線附近分批逢低佈局，短線不盲目追高。`;
  }

  return `您好！我是您的 AI 戰情投資顧問。根據您當前的資產組合（總市值 $${Math.round(valNum).toLocaleString()} TWD，報酬率 ${roiNum.toFixed(1)}%）：\n\n- **持股現況**：您目前佈局了 ${portfolio.length} 檔標的，重倉核心為 **${topName}**。\n- **市場策略**：當前台美股均處於多空交會點，建議依循「汰弱留強、分批佈局」法則。\n\n請問您對哪一檔個股（例如台積電、美股科技股）或哪種操盤策略需要更深入的解析？`;
}

// 7. Gemini AI Portfolio Copilot Endpoint
app.post('/api/ai-analysis', async (req, res) => {
  const { portfolio = [], totalValue = 0, totalProfit = 0, totalROI = 0, indices = [] } = req.body;

  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.json({
        success: true,
        analysis: generateRuleBasedAnalysis(portfolio, totalValue, totalProfit, totalROI),
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const prompt = `你是一位精通台股與美股的資深首席投資顧問 (Chief Investment Officer)。
請針對用戶目前的持股投資組合進行全方位的「AI 戰情分析診斷」：

【用戶投資組合數據】:
- 總估值 (NT$): ${totalValue}
- 未實現損益 (NT$): ${totalProfit}
- 總報酬率 (%): ${totalROI}%
- 持股明細: ${JSON.stringify(portfolio, null, 2)}
- 國際大盤現況: ${JSON.stringify(indices, null, 2)}

請提供結構化的 JSON 診斷報告，內容必須繁體中文，格式嚴格遵循 JSON 規範：
{
  "summary": "一句話精闢總結目前的整體持股健康狀況與走勢表現",
  "riskRating": "低風險 | 中等風險 | 高風險 | 極高風險",
  "allocationComment": "針對台美股比例、個股集中度與產業分散度的詳細講評",
  "topOpportunities": ["潛力亮點或利多因素 1", "潛力亮點 2"],
  "riskWarnings": ["潛在風險點或需要注意的個股 1", "風控提醒 2"],
  "actionAdvice": "具體可執行的操盤建議 (例如：適度止盈、回檔逢低分批加碼、設好停損)"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        systemInstruction: '你是一位講求數據實證、嚴守風控與專業客觀的資深台美股操盤手顧問。',
      },
    });

    const text = response.text || '{}';
    const resultJson = JSON.parse(text);

    res.json({
      success: true,
      analysis: {
        ...resultJson,
        timestamp: new Date().toLocaleString('zh-TW', { timeZone: 'Asia/Taipei' }),
      },
    });
  } catch (error) {
    res.json({
      success: true,
      analysis: generateRuleBasedAnalysis(portfolio, totalValue, totalProfit, totalROI),
    });
  }
});

// 8. Gemini AI Real-time Live Q&A Chat Endpoint
app.post('/api/ai-chat', async (req, res) => {
  const { message = '', history = [], portfolio = [], totalValue = 0, totalProfit = 0, totalROI = 0, indices = [], customApiKey = '' } = req.body;

  try {
    const apiKey = customApiKey || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.json({
        success: true,
        reply: generateRuleBasedChatReply(message, portfolio, totalValue, totalProfit, totalROI),
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const contextPrompt = `你是一位講求數據、嚴守風控且極具親和力的資深台美股首席投資顧問。
目前用戶的資產庫狀況如下：
- 總估值: $${totalValue} TWD
- 累積損益: $${totalProfit} TWD (${totalROI}%)
- 持股明細: ${JSON.stringify(portfolio)}
- 大盤指數: ${JSON.stringify(indices)}

【對話歷史】:
${JSON.stringify(history)}

【用戶最新的問題/指示】:
${message}

請以繁體中文回答用戶的問題，給予精準、有建設性且條理分明的操盤建議與市場解讀。請使用清晰的 Markdown 格式 (列表與粗體) 呈現。`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: contextPrompt,
      config: {
        systemInstruction: '你是一位精通台股與美股的資深操盤手顧問，請提供即時專業、條理分明且客觀的回答。',
      },
    });

    const reply = response.text || '非常抱歉，目前暫時無法回應您的問題，請稍後再試。';

    res.json({
      success: true,
      reply,
    });
  } catch (error) {
    res.json({
      success: true,
      reply: generateRuleBasedChatReply(message, portfolio, totalValue, totalProfit, totalROI),
    });
  }
});

// Vite middleware / static files
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 資產戰情室 Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
